"""
This is the main file that trains and evaluates the neural-network-based PID controller for a 2R robotic ram
============================================================================================================
Supplementary materials for EE4307, Wang, Bingheng, wangbingheng@u.nus.edu, at Control & Simulation Lab
"""

import Dynamics
import neural_network
from casadi import *
import numpy as np
import matplotlib.pyplot as plt
import torch
from numpy import linalg as LA

"""---------------------------------Learn or Evaluate?-------------------------------------"""
train = True

