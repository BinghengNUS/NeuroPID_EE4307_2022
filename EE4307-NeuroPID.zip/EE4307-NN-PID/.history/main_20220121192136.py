"""
This is the main file that trains and evaluates the neural-network-based PID controller for a 2R robotic ram
============================================================================================================
Supplementary materials for EE4307, Wang, Bingheng, wangbingheng@u.nus.edu, at Control & Simulation Lab
"""

import Dynamics
import control
import neural_network
from casadi import *
import numpy as np
import matplotlib.pyplot as plt
import torch
from numpy import linalg as LA
import math

"""---------------------------------Train or Evaluate?-------------------------------------"""
train = True

"""---------------------------------Simualtion Settings------------------------------------"""
# simulation time-step [second]
t_step = 1e-3
# sampling time-step [second]
dt_sample = 1e-2
# Simulation time [second]
t_end  = 5
# learning rate
lr_nn = 1e-4
# load the environment
para  = np.array([1,1,0.5,0.5,1])
robot = Dynamics.robots(para)
"""---------------------------------Define Neural Network Model----------------------------"""
D_in, D_h, D_out = 6, 20, 6
nn_gain = neural_network.Net(D_in, D_h, D_out)

"""---------------------------------Define Controller--------------------------------------"""
PIDctrl = control.controller(robot.B, robot.theta1, robot.theta2, robot.dtheta1, robot.dtheta2)

"""---------------------------------Training Process---------------------------------------"""


def Train():
    # loss function
    Loss = []
    # criterion for stopping the learning
    eps = 1e-2
    delta_loss = 10 # initialization of the change of loss
    # iteration index
    i = 0

    while delta_loss >= eps:
        time = 0
        # initial state
        state = np.zeros((4, 1))
        # desired state
        des_state = np.array([[math.pi/6, 0, math.pi/6, 0]]).T
        # initial integral error
        ie1, ie2 = 0, 0
        for j in range(int(t_end/t_step)):
            





