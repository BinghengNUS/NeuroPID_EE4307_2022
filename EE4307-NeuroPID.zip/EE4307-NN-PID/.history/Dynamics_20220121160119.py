"""
This file defines the dynamics model of the 2R robotic arm.
==========================================================
Supplementary material for EE4307, Wang, Bingheng
"""

from casadi import *
import numpy as np
import math
from numpy import linalg as LA

class robots:
    def __init__(self, para):
        # system parameters
        self.mass1 = para[0]
        self.mass2 = para[1]
        self.r1    = para[2]
        self.r2    = para[3]
        self.L1    = para[4]
        # Joint angular position
        self.theta1 = SX.sym('t1')
        self.theta2 = SX.sym('t2')
        # Joint angular rate
        self.dtheta1 = SX.sym('dt1')
        self.dtheta2 = SX.sym('dt2')
        # control input
        self.tau1 = SX.sym('tau1')
        self.tau2 = SX.sym('tau2')
        self.ctrl = vertcat(self.tau1, self.tau2)
    
    def model(self):
        # gravity constant
        g = 9.81
        # Inertial matrix M
        m11 = self.mass1*self.r1**2+self.mass2*(self.L1**2+2*self.L1*self.r2*math.cos(self.theta2)+self.r2**2)
        m12 = self.mass2*self.r2*(self.r2+self.L1*math.cos(self.theta2))
        m21 = m12
        m22 = self.mass2*self.r2**2
        self.M = vertcat(
            horzcat(m11, m12),
            horzcat(m21, m22)
        )
        # Coriolis and centrifugal matrix C 
        c11 = -self.mass2*self.r2*self.L1*math.sin(self.theta2)*(2*self.dtheta1*self.dtheta2+self.dtheta2**2)
        c21 =  self.mass2*self.L1*self.r2*math.sin(self.theta2)*self.dtheta1**2
        self.C = vertcat(c11,c21)
        # Gravity matrix G
        g11 = self.mass1*g*self.r1*math.cos(self.theta1)+self.mass2*g*(self.L1*math.cos(self.theta1)+self.r2*math.cos(self.theta1+self.theta2))
        g21 = self.mass2*g*self.r2*math.cos(self.theta1+self.theta2)
        self.G = vertcat(g11,g21)
        # Define the system state x = [theta1, theta2, dtheta1, dtheta2]
        self.x = vertcat(self.theta1, self.theta2, self.dtheta1, self.dtheta2)
        # 2nd-order dynamics model ddtheta = M^(-1)*(ctrl-C-G)
        self.ddtheta = mtimes(inv(self.M), self.ctrl-self.C-self.G)
        # State-space form dx = f(x,u)
        self.dx = vertcat(self.dtheta1,self.dtheta2,self.ddtheta)
        self.dx_fn = Function('Dyn_ss',[self.x, self.ctrl],[self.dx],['x0','ctrl0'],['Dyn_ssf'])
        # Control mapping matrix M^(-1)
        self.B = inv(self.M)
        self.B_fn  = Function('B',[self.theta1, self.theta2],[self.B],['theta_1','theta_2'],['Bf'])

    def step(self, state, control, dt):
        self.model()
        # Define the discrete-time dynamics model using 4th order Runge-Kutta method
        k1 = self.dx_fn(x0=state, ctrl0=control)['Dyn_ssf'].full()
        k2 = self.dx_fn(x0=state+dt/2*k1, ctrl0=control)['Dyn_ssf'].full()
        k3 = self.dx_fn(x0=state+dt/2*k2, ctrl0=control)['Dyn_ssf'].full()
        k4 = self.dx_fn(x0=state+dt*k3, ctrl0=control)['Dyn_ssf'].full()
        dx = (k1 + 2*k2 + 2*k3 + k4)/6
        state_new = state + dt*dx
        return state_new

