"""
This is the main file that trains and evaluates the neural-network-based PID controller for a 2R robotic ram
============================================================================================================
Supplementary materials for EE4307, Wang, Bingheng, wangbingheng@u.nus.edu, at Control & Simulation Lab
"""

import Dynamics
import control
import neural_network
from casadi import *
import numpy as np
import matplotlib.pyplot as plt
import torch
from numpy import linalg as LA
import math

"""---------------------------------Train or Evaluate?-------------------------------------"""
train = True

"""---------------------------------Simualtion Settings------------------------------------"""
# simulation time-step [second]
t_step = 1e-3
# sampling time-step [second]
dt_sample = 5e-3
ratio = int(dt_sample/t_step)
# Simulation time [second]
t_end  = 5
# learning rate
lr_nn = 1e-4
# load the environment
para  = np.array([10,0.01,0.5,0.5,1])
robot = Dynamics.robots(para)
robot.model()
"""---------------------------------Define Neural Network Model----------------------------"""
D_in, D_h, D_out = 6, 10, 6
nn_gain = neural_network.Net(D_in, D_h, D_out)

"""---------------------------------Define Controller--------------------------------------"""
kmin, kmax, k2min, k2max, kimin, kimax = 1e-1, 1, 1e-5, 1e-1, 1e-5, 1e-1
k = 1
PIDctrl = control.controller(robot.B, robot.theta1, robot.theta2, robot.dtheta1, robot.dtheta2, kmin, kmax, kimin, kimax, k2max, k2min, k)

"""---------------------------------Training Process---------------------------------------"""
def convert(para): # convert tensor to array
    NN_output = np.zeros((1, 6))
    for i in range(6):
        NN_output[0, i] = para[i, 0]
    return NN_output

def NNoutput_to_gain(output): # convert the NN output to control gain
    kp1 = kmin + (kmax-kmin)*output[0,0]
    ki1 = kimin + (kimax-kimin)*output[0,1]
    kd1 = kmin + (kmax-kmin)*output[0,2]
    kp2 = k2min + (k2max-k2min)*output[0,3]
    ki2 = kimin + (kimax-kimin)*output[0,4]
    kd2 = k2min + (k2max-k2min)*output[0,5]
    ctrl_gain = np.hstack((kp1,ki1,kd1,kp2,ki2,kd2))
    return ctrl_gain

def Train():
    # criterion for stopping the learning
    eps = 1e-2
    delta_loss = 10 # initialization of the change of loss
    # iteration index
    i = 0
    # initial mean loss
    mean_loss0 = 0
    # list for storing the position trajectory during the training
    joint_angle = []
    # list for storing the mean loss during the training
    MEAN_loss = []
    # list for storing the epoch index
    I = []
    while delta_loss >= eps:
        time = 0
        # initial state
        state = np.zeros((4, 1))
        # desired position
        des_state = np.array([[math.pi/6, math.pi/6]]).T
        # initial integral error
        ie1, ie2 = 0, 0
        # initial summation of loss
        sum_loss = 0
        # build a matrix to store the system state during the training
        STATE = np.zeros((4, int(t_end/t_step)))
        for j in range(int(t_end/t_step)): # simulation frequency = 1k hz
            # store the current state
            STATE[:,j:j+1] = state
            if (j%ratio)==0: # control frequency = 100 hz
                # compute the position tracing errors
                e1 = des_state[0,0]-state[0,0]
                e2 = des_state[1,0]-state[1,0]
                print('epoch:',i,'time:',time, 'state=',state.T)
                # compute the integrated position tracking errors
                ie1 = ie1 + (des_state[0,0] - state[0,0])*dt_sample
                ie2 = ie2 + (des_state[1,0] - state[1,0])*dt_sample
                # compute the velocity tracking errors
                de1 = -state[2,0]
                de2 = -state[3,0]
                # formulate the tracking error vector used in the controller
                errors = np.vstack((e1, ie1, de1, e2, ie2, de2))
                # compute the current loss
                loss   = PIDctrl.Loss(errors)
                sum_loss = sum_loss + loss
                print('epoch:',i,'time:',time,'loss=',loss)
                if i>0: # we do not train the neural network in the first epoch for the sake of comparison
                    dldnn_output = PIDctrl.Gradient(errors, state)
                    loss_nn_p    = nn_gain.myloss(nn_gain(NN_input), dldnn_output) # construct the loss function for training the neural network
                    optimizer_p = torch.optim.Adam(nn_gain.parameters(), lr=lr_nn)
                    nn_gain.zero_grad()
                    loss_nn_p.backward()
                    optimizer_p.step()

                # compute the neural control gain
                NN_input = np.vstack((des_state, state[0,0], state[1,0], e1, e2))
                NN_output = convert(nn_gain(NN_input))
                ctrl_gain = NNoutput_to_gain(NN_output)
                print('epoch:',i,'time:',time, 'control gain=',ctrl_gain)
                # compute the control torque using the PID control law, updated every 10 simulation steps
                ctrl_torque = PIDctrl.PID(errors, ctrl_gain)
            # apply the control torque to the robotic arm, and integrate the closed-loop system forward in one step to obtain the new state
            new_state = robot.step(state, ctrl_torque, t_step)
            # update the state and time
            state = new_state
            time  = time + t_step
        # append the index to thelist
        I += [i]
        # update the epoch index
        i = i + 1
        # append STATE to the list
        joint_angle += [STATE]
        # compute the mean loss over one epoch
        mean_loss = sum_loss / int(t_end/dt_sample)
        print('epoch:',i,'mean loss=',mean_loss)
        # append mean_loss to the list
        MEAN_loss += [mean_loss]
        # compute the change of the mean loss
        delta_loss = abs(mean_loss - mean_loss0)
        mean_loss0 = mean_loss
        # save the trained neural network model
        PATH1 = "Trained_nn_gain.pt"
        torch.save(nn_gain, PATH1)
        np.save('Joint_angle_training',joint_angle)
        np.save('MEAN_Loss',MEAN_loss)
        np.save('INDEX_training',I)


def Evaluate():
    # Load the trained neural network model
    PATH1 = "Trained_nn_gain.pt"
    nn_gain = torch.load(PATH1)
    time = 0
    Time = np.zeros((1, int(t_end/t_step)))
    # initial state
    state = np.zeros((4, 1))
    # desired position
    des_state = np.array([[math.pi/4, math.pi/6]]).T
    # initial integral error
    ie1, ie2 = 0, 0
    # build a matrix to store the system state during the training
    STATE = np.zeros((4, int(t_end/t_step)))
    # build a matrix to store the control torque
    CONTROL = np.zeros((2, int(t_end/t_step)))
    # build a matrix to store the control gain
    GAIN    = np.zeros((int(t_end/t_step),6))
    # build a matrix to store the desired state
    REFERENCE = np.zeros((2, int(t_end/t_step)))
    for j in range(int(t_end/t_step)): # simulation frequency = 1k hz
        # store the current state, time, and the reference
        STATE[:,j:j+1] = state
        Time[:,j:j+1]  = time
        REFERENCE[:,j:j+1] = des_state
        if (j%ratio)==0: # control frequency = 100 hz
            # compute the position tracing errors
            e1 = des_state[0,0]-state[0,0]
            e2 = des_state[1,0]-state[1,0]
            print('time:',time, 'state=',state.T)
            # compute the integrated position tracking errors
            ie1 = ie1 + (des_state[0,0] - state[0,0])*dt_sample
            ie2 = ie2 + (des_state[1,0] - state[1,0])*dt_sample
            # compute the velocity tracking errors
            de1 = -state[2,0]
            de2 = -state[3,0]
            # formulate the tracking error vector used in the controller
            errors = np.vstack((e1, ie1, de1, e2, ie2, de2))
            # compute the neural control gain
            NN_input = np.vstack((des_state, state[0,0], state[1,0], e1, e2))
            NN_output = convert(nn_gain(NN_input))
            ctrl_gain = NNoutput_to_gain(NN_output)
            # compute the control torque using the PID control law, updated every 10 simulation steps
            ctrl_torque = PIDctrl.PID(errors, ctrl_gain)
        # store the control torque
        CONTROL[:,j:j+1] = ctrl_torque
        # store the control gain
        GAIN[j:j+1,:] = ctrl_gain
        # apply the control torque to the robotic arm, and integrate the closed-loop system forward in one step to obtain the new state
        new_state = robot.step(state, ctrl_torque, t_step)
        # update the state and time
        state = new_state
        time  = time + t_step
    np.save('STATE_evaluation',STATE)
    np.save('Time',Time)
    np.save('CONTROL_evaluation',CONTROL)
    np.save('GAIN_evaluation',GAIN)
    np.save('REFERENCE_evaluation',REFERENCE)

    """---------Plot the results---------"""
    # mean loss during the training
    mean_loss = np.load('MEAN_Loss.npy')
    epoch     = np.load('INDEX_training.npy')
    plt.figure(1)
    plt.plot(epoch, mean_loss, linewidth=1.5, marker='o')
    plt.xlabel('Training epoch')
    plt.ylabel('Mean loss')
    plt.grid()
    plt.savefig('./mean_loss.png',dpi=300)
    plt.show()
    # first joint angle
    plt.figure(2)
    plt.plot(Time, STATE[0,:], linewidth=1.5)
    plt.plot(Time, REFERENCE[0,:], linewidth=1)
    plt.xlabel('Time [s]')
    plt.ylabel('First Joint Angle [rad]')
    plt.legend(['Joint angle', 'Reference'])
    plt.grid()
    plt.savefig('./first_angle.png',dpi=300)
    plt.show()
    # second joint angle
    plt.figure(3)
    plt.plot(Time, STATE[1,:], linewidth=1.5)
    plt.plot(Time, REFERENCE[1,:], linewidth=1)
    plt.xlabel('Time [s]')
    plt.ylabel('Second Joint Angle [rad]')
    plt.legend(['Joint angle', 'Reference'])
    plt.grid()
    plt.savefig('./second_angle.png',dpi=300)
    plt.show()
    # control gain for the first control torque
    plt.figure(4)
    plt.plot(Time, GAIN[:,0], linewidth=1)
    plt.plot(Time, GAIN[:,1], linewidth=1)
    plt.plot(Time, GAIN[:,2], linewidth=1)
    plt.xlabel('Time [s]')
    plt.ylabel('PID gain')
    plt.legend(['kp', 'ki','kd'])
    plt.grid()
    plt.savefig('./first_pid_gain.png',dpi=300)
    plt.show()
    # control gain for the second control torque
    plt.figure(4)
    plt.plot(Time, GAIN[:,3], linewidth=1)
    plt.plot(Time, GAIN[:,4], linewidth=1)
    plt.plot(Time, GAIN[:,5], linewidth=1)
    plt.xlabel('Time [s]')
    plt.ylabel('PID gain')
    plt.legend(['kp', 'ki','kd'])
    plt.grid()
    plt.savefig('./second_pid_gain.png',dpi=300)
    plt.show()

"""---------------------------------Main function-----------------------------"""
if train:
    Train()
    Evaluate()
else:
    Evaluate()

        
        
                


            




            






