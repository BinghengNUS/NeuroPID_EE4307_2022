"""
This is the main file that trains and evaluates the neural-network-based PID controller for a 2R robotic ram
============================================================================================================
Supplementary materials for EE4307, Wang, Bingheng, wangbingheng@u.nus.edu, at Control & Simulation Lab
"""

import Dynamics
import control
import neural_network
from casadi import *
import numpy as np
import matplotlib.pyplot as plt
import torch
from numpy import linalg as LA
import math

"""---------------------------------Train or Evaluate?-------------------------------------"""
train = True

"""---------------------------------Simualtion Settings------------------------------------"""
# simulation time-step [second]
t_step = 1e-3
# sampling time-step [second]
dt_sample = 1e-2
ratio = int(dt_sample/t_step)
# Simulation time [second]
t_end  = 5
# learning rate
lr_nn = 1e-4
# load the environment
para  = np.array([1,1,0.5,0.5,1])
robot = Dynamics.robots(para)
"""---------------------------------Define Neural Network Model----------------------------"""
D_in, D_h, D_out = 6, 20, 6
nn_gain = neural_network.Net(D_in, D_h, D_out)

"""---------------------------------Define Controller--------------------------------------"""
kmin, kmax = 1e-2, 10
PIDctrl = control.controller(robot.B, robot.theta1, robot.theta2, robot.dtheta1, robot.dtheta2, kmin, kmax)

"""---------------------------------Training Process---------------------------------------"""
def convert(para): # convert tensor to array
    NN_output = np.zeros((1, 6))
    for i in range(6):
        NN_output[0, i] = para[i, 0]
    return NN_output

def NNoutput_to_gain(output): # convert the NN output to control gain
    kp1 = kmin + (kmax-kmin)*output[0,0]
    ki1 = kmin + (kmax-kmin)*output[0,1]
    kd1 = kmin + (kmax-kmin)*output[0,2]
    kp2 = kmin + (kmax-kmin)*output[0,3]
    ki2 = kmin + (kmax-kmin)*output[0,4]
    kd2 = kmin + (kmax-kmin)*output[0,5]
    ctrl_gain = np.hstack((kp1,ki1,kd1,kp2,ki2,kd2))
    return ctrl_gain

def Train():
    # criterion for stopping the learning
    eps = 1e-3
    delta_loss = 10 # initialization of the change of loss
    # iteration index
    i = 0
    # initial mean loss
    mean_loss0 = 0
    # list for storing the position trajectory during the training
    joint_angle = []
    while delta_loss >= eps:
        time = 0
        # initial state
        state = np.zeros((4, 1))
        # desired position
        des_state = np.array([[math.pi/6, math.pi/6]]).T
        # initial integral error
        ie1, ie2 = 0, 0
        # initial summation of loss
        sum_loss = 0
        # build a matrix to store the system state during the training
        STATE = np.zeros((4, int(t_end/t_step)))
        for j in range(int(t_end/t_step)): # simulation frequency = 1k hz
            # store the current state
            STATE[:,j] = state
            if (j%ratio)==0: # control frequency = 100 hz
                # compute the position tracing errors
                e1 = des_state[0,0]-state[0,0]
                e2 = des_state[1,0]-state[1,0]
                print('epoch:',i,'time:',time, 'joint1 state =', np.array([[state[0,0],state[2,0]]], 'joint2 state =', np.array([[state[1,0],state[3,0]]])))
                # compute the integrated position tracking errors
                ie1 = ie1 + (des_state[0,0] - state[0,0])*dt_sample
                ie2 = ie2 + (des_state[1,0] - state[1,0])*dt_sample
                # compute the velocity tracking errors
                de1 = -state[2,0]
                de2 = -state[3,0]
                # formulate the tracking error vector used in the controller
                errors = np.vstack((e1, ie1, de1, e2, ie2, de2))
                # compute the current loss
                loss   = PIDctrl.Loss(errors)
                sum_loss = sum_loss + loss
                print('epoch:',i,'time:',time,'loss=',loss)
                if i>0: # we do not train the neural network in the first epoch for the sake of comparison
                    dldnn_output = PIDctrl.Gradient(errors, state)
                    loss_nn_p    = nn_gain.myloss(nn_gain(NN_input), dldnn_output) # construct the loss function for training the neural network
                    optimizer_p = torch.optim.Adam(nn_gain.parameters(), lr=lr_nn)
                    nn_gain.zero_grad()
                    loss_nn_p.backward()
                    optimizer_p.step()

                # compute the neural control gain
                NN_input = np.vstack((des_state, state[0,0], state[1,0], e1, e2))
                NN_output = convert(nn_gain(NN_input))
                ctrl_gain = NNoutput_to_gain(NN_output)
                # compute the control torque using the PID control law, updated every 10 simulation steps
                ctrl_torque = PIDctrl.PID(errors, ctrl_gain)

            # apply the control torque to the robotic arm, and integrate the closed-loop system forward in one step to obtain the new state
            new_state = robot.step(state, ctrl_torque, t_step)
            # update the state and time
            state = new_state
            time  = time + t_step
        # update the epoch index
        i = i + 1
        # append STATE to the list
        joint_angle += [STATE]
        # compute the mean loss over one epoch
        mean_loss = sum_loss / int(t_end/dt_sample)
        # compute the change of the mean loss
        delta_loss = abs(mean_loss - mean_loss0)
        mean_loss0 = mean_loss
        # save the trained neural network model
        PATH1 = "Trained_nn_gain.pt"
        torch.save(nn_gain, PATH1)
        np.save('Joint_angle_training',joint_angle)


def Evaluate():
    # Load the trained neural network model
    PATH1 = "Trained_nn_gain.pt"
    nn_gain = torch.load(PATH1)
    time = 0
    # initial state
    state = np.zeros((4, 1))
    # desired position
    des_state = np.array([[math.pi/4, math.pi/6]]).T
    # initial integral error
    ie1, ie2 = 0, 0
    # build a matrix to store the system state during the training
    STATE = np.zeros((4, int(t_end/t_step)))
    for j in range(int(t_end/t_step)): # simulation frequency = 1k hz
        # store the current state
        STATE[:,j] = state
        if (j%ratio)==0: # control frequency = 100 hz
            # compute the position tracing errors
            e1 = des_state[0,0]-state[0,0]
            e2 = des_state[1,0]-state[1,0]
            print('time:',time, 'joint1 state =', np.array([[state[0,0],state[2,0]]], 'joint2 state =', np.array([[state[1,0],state[3,0]]])))
            # compute the integrated position tracking errors
            ie1 = ie1 + (des_state[0,0] - state[0,0])*dt_sample
            ie2 = ie2 + (des_state[1,0] - state[1,0])*dt_sample
            # compute the velocity tracking errors
            de1 = -state[2,0]
            de2 = -state[3,0]
            # formulate the tracking error vector used in the controller
            errors = np.vstack((e1, ie1, de1, e2, ie2, de2))
            # compute the neural control gain
            NN_input = np.vstack((des_state, state[0,0], state[1,0], e1, e2))
            NN_output = convert(nn_gain(NN_input))
            ctrl_gain = NNoutput_to_gain(NN_output)
            # compute the control torque using the PID control law, updated every 10 simulation steps
            ctrl_torque = PIDctrl.PID(errors, ctrl_gain)
            # apply the control torque to the robotic arm, and integrate the closed-loop system forward in one step to obtain the new state
            new_state = robot.step(state, ctrl_torque, t_step)
            # update the state and time
            state = new_state
            time  = time + t_step
        
        
                


            




            






