"""
This file defines the PID controller whose gains are represented by a nerual network
====================================================================================
Supplementary materials for EE4307, Wang, Bingheng
"""

from casadi import *
from numpy import linalg as LA
import numpy as np
import math

class controller:
    def __init__(self, ctrl_map, theta1, theta2, dtheta1, dtheta2):
        self.kp1 = SX.sym('kp1')
        self.kp2 = SX.sym('kp2')
        self.kd1 = SX.sym('kd1')
        self.kd2 = SX.sym('kd2')
        self.ki1 = SX.sym('ki1')
        self.ki2 = SX.sym('ki2')
        self.gain = horzcat(self.kp1, self.ki1, self.kd1, self.kp2, self.ki2, self.kd2)
        self.e1  = SX.sym('e1') # tracking error for the joint 1
        self.e2  = SX.sym('e2') # tracking error for the joint 2
        self.de1 = SX.sym('de1')# derivative of the tracking error 1
        self.de2 = SX.sym('de2')# derivative of the tracking error 2
        self.ie1 = SX.sym('ie1')# integral of the tracking error 1
        self.ie2 = SX.sym('ie2')# integral of the tracking error 2
        self.error = vertcat(self.e1, self.ie1, self.de1, self.e2, self.ie2, self.de2)
        self.tau1 = self.kp1*self.e1 + self.ki1*self.ie1 + self.kd1*self.de1
        self.tau2 = self.kp2*self.e2 + self.ki2*self.ie2 + self.kd2*self.de2
        self.ctrl = vertcat(self.tau1, self.tau2)
        self.ctrl_fn = Function('ctrl',[self.error, self.gain], [self.ctrl], ['error0','gain0'], ['ctrlf'])
        self.grad = jacobian(self.ctrl, self.gain)
        self.grad_fn = Function('grad',[self.error], [self.grad], ['error0'], ['gradf'])
        self.B = ctrl_map
        self.t1 = theta1
        self.t2 = theta2
        self.dt1 = dtheta1
        self.dt2 = dtheta2
        self.state = vertcat(self.t1, self.t2, self.dt1, self.dt2)
        self.B_fn  = Function('B',[self.state],[self.B],['state0'],['Bf'])
        self.loss = self.e1**2 + self.e2**2
        self.eout = horzcat(self.e1, self.e2)
        self.loss_fn = Function('loss',[self.error], [self.loss], ['error0'], ['lossf'])
        self.dlde = jacobian(self.loss, self.eout) # gradient of the loss w.r.t output tracking errors
        self.dlde_fn = Function('dlde',[self.error], [self.dlde], ['error0'], ['dldef'])
    
    def PID(self, errors, pid_gain):
        control_signal = self.ctrl_fn(error0=errors, gain0=pid_gain)['ctrlf'].full()
        return control_signal
    
    def Gradient(self, errors, state):
        grad_loss = self.dlde_fn(error0=errors)['dldef'].full()
        grad_ctrl = self.B_fn(state0=state)['Bf'].full()
        grad_pid  = self.grad_fn(error0=errors)['gradf'].full()
        grad = np.matmul(grad_loss, np.matmul(grad_ctrl, grad_pid))
        return grad
       


    
